@extends('Empdash.Layouts.Main')
@section('title')
    {{ 'Dashboard' }}
@endsection
@section('main-container')
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
           
        </div>
    </div>
@endsection
