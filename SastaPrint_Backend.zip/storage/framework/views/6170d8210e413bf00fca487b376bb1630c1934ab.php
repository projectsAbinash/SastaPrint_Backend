
<?php $__env->startSection('title'); ?>
    <?php echo e('Employee Lists'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
<?php if($view == 'list'): ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="card">
                <h5 class="card-header">Employee Details</h5>
                <div class="table-responsive text-nowrap">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">Pictuer</th>
                                <th class="text-center">Name</th>
                                <th class="text-center">Phone</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"> <img style="max-height: 45px;" src="<?php echo e($data->Eprofile->profile_pic); ?>" alt="Avatar"
                                            class="rounded-circle" />
                                    </td>
                                    <td class="text-center fw-bold"><?php echo e($data->name); ?></td>
                                    <td class="text-center">
                                        <?php echo e($data->phone); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php if($data->phone_verified_at =! null): ?>
                                        <span class="badge bg-label-success me-1">Verified</span>
                                       <?php else: ?>
                                       <span class="badge bg-label-success me-1">Unverified</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="text-center">
                                        <a href="<?php echo e(route('admin.emp.get',(['id' => $data->id]))); ?>">
                                        <i class="bx bx-line-chart text-success"  style="font-size:23px;"></i>
                                    </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php elseif($view == 'details'): ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
           
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admins.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\Sastaprint\SastaPrint_Backend\resources\views/Admins/emp/employeeview.blade.php ENDPATH**/ ?>