
<?php $__env->startSection('title'); ?>
    <?php echo e('Dashboard'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
           
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Empdash.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\Sastaprint\SastaPrint_Backend\resources\views/Empdash/dashboard.blade.php ENDPATH**/ ?>