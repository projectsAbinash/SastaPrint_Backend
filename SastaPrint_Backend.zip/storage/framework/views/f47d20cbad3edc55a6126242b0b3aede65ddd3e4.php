
<?php $__env->startSection('title'); ?>
    <?php echo e('Create Employee Panels'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.css"
            integrity="sha512-In/+MILhf6UMDJU4ZhDL0R0fEpsp4D3Le23m6+ujDWXwl3whwpucJG1PEmI3B07nyJx+875ccs+yX2CqQJUxUw=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
        <div class="content-wrapper">
            <form action="<?php echo e(route('Admin.employee.register')); ?>" method="POST" enctype="multipart/form-data">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="card mb-4">
                        <h5 class="card-header">Create Employees</h5>
                        <!-- Account -->

                        <div class="card-body">
                            <div class="d-flex align-items-start align-items-sm-center gap-4">
                                <img src="<?php echo e(url('AdminAssets/Source/assets/img/pngwing.com.png')); ?>" alt="user-avatar"
                                    class="d-block rounded" height="100" width="100" id="imgPreview" />
                                <div class="button-wrapper">
                                    <label for="upload" class="btn btn-primary me-2 mb-4">
                                        <span class="d-none d-sm-block">Upload new photo</span>
                                        <i class="bx bx-upload d-block d-sm-none"></i>
                                        <input type="file" id="upload" class="account-file-input" hidden
                                            accept="image/png, image/jpeg" name="profile" />
                                    </label>

                                    <p class="text-muted mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                                </div>
                            </div>
                        </div>

                        <hr class="my-0" />
                        <div class="card-body">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?><br />
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>

                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="firstName" class="form-label">Full Name</label>
                                    <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        value="<?php echo e(old('name')); ?>" id="firstName" name="name" autofocus />
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label for="Phone" class="form-label">Phone Number</label>
                                    <input class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number"
                                        value="<?php echo e(old('phone')); ?>" id="Phone" name="phone" autofocus />
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label for="Aadhar" class="form-label">Aadhar Number</label>
                                    <input class="form-control <?php $__errorArgs = ['aadhar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        value="<?php echo e(old('aadhar')); ?>" id="iban" name="aadhar" autofocus />
                                </div>

                                <div class="mb-3 col-md-6">
                                    <label for="Password" class="form-label">Password</label>
                                    <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                        id="iban" name="password" autofocus />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="fside" class="form-label">Aadhar Front Side</label>
                                    <input class="form-control dropify" type="file" id="fside" name="faadhar"
                                        autofocus />
                                </div>
                                <div class="mb-3 col-md-6">
                                    <label for="bside" class="form-label">Aadhar Back Side</label>
                                    <input class="form-control dropify" type="file" id="bside" name="baadhar"
                                        autofocus />
                                </div>

                            </div>
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary me-2">Register</button>
                                <a href="<?php echo e(route('DashboardIndex')); ?>"><button type="button"
                                        class="btn btn-outline-secondary">Cancel</button></a>
                            </div>
            </form>
        </div>
        <!-- /Account -->
        </div>
        </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.js"
            integrity="sha512-hJsxoiLoVRkwHNvA5alz/GVA+eWtVxdQ48iy4sFRQLpDrBPn6BFZeUcW4R4kU+Rj2ljM9wHwekwVtsb0RY/46Q=="
            crossorigin="anonymous" referrerpolicy="no-referrer"></script>

        <script>
            $(document).ready(() => {
                $("#upload").change(function() {
                    const file = this.files[0];
                    if (file) {
                        let reader = new FileReader();
                        reader.onload = function(event) {
                            $("#imgPreview")
                                .attr("src", event.target.result);
                        };
                        reader.readAsDataURL(file);
                    }
                });
            });
            $('.dropify').dropify({
                messages: {
                    'default': 'Click To Upload',
                    'replace': 'Drag and drop or click to replace',
                    'remove': 'Remove',
                    'error': 'Ooops, something wrong happended.'
                }
            });
        </script>
    
        
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admins.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\htdocs\Sastaprint\SastaPrint_Backend\resources\views/Admins/emp/Newemployee.blade.php ENDPATH**/ ?>