
<?php $__env->startSection('title'); ?>
    <?php echo e('Orders Manage'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <?php if($view == 'list'): ?>
                <div class="card">
                    <div class="row m-3">
                        <div class="col">
                            <h5 class="card-header">Orders List</h5>
                        </div>


                    </div>


                    <div class="table-responsive text-nowrap">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Type</th>
                                    <th class="text-center">Customer name</th>
                                    <th class="text-center">Order Id</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php
                                    $i = 0;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $i++;
                                    ?>
                                    <tr>
                                        <td class="text-center">
                                            <?php echo e($i); ?>

                                        </td>
                                        <td class="text-center">
                                            <img style="max-height: 45px;"
                                                src="<?php echo e(url('AdminAssets/Source/assets/img/pdf.jpg')); ?>" alt="Avatar" />
                                        </td>
                                        <td class="text-center">
                                            <?php echo e($item->Getuser->name); ?>

                                        </td>
                                        <td class="text-center fw-bold">
                                            #<?php echo e($item->order_id); ?>

                                        </td>
                                        <td class="text-center fw-bold">
                                            ₹<?php echo e($item->amount); ?>


                                        </td>

                                        <td class="text-center">
                                            <?php if($item->status == 'placed'): ?>
                                                <span class="badge bg-label-info me-1">Placed</span>
                                            <?php elseif($item->status == 'shipped'): ?>
                                                <span class="badge bg-label-warning me-1">Shipped</span>
                                            <?php elseif($item->status == 'deliverd'): ?>
                                                <span class="badge bg-label-success me-1">Delivred</span>
                                            <?php else: ?>
                                                <span class="badge bg-label-danger me-1"><?php echo e($item->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('emp.order.manage', ['id' => $item->order_id])); ?>"> <i
                                                    class="fa-regular fa-eye text-primary" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="View And Manage Order"
                                                    style="font-size:20px;"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            <?php elseif($view == 'details'): ?>
                <div class="row">
                    <div class="col-md-12">

                        <div class="card mb-4">
                            <h5 class="card-header">Manage Order</h5>
                            <!-- Account -->

                            <hr class="my-0" />
                            <div class="card-body">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <form id="formAccountSettings" method="POST" onsubmit="return false">

                                    <div class="">
                                        <div class="row">
                                            <div class="col">
                                                <table class="table table-bordered mb-4">

                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                Date
                                                            </td>
                                                            <td> <strong><?php echo e($data->created_at->format('d-m-Y')); ?></strong>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                Order ID
                                                            </td>
                                                            <td> <strong><?php echo e($data->order_id); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                Customer Name
                                                            </td>
                                                            <td> <strong><?php echo e($data->Getuser->name); ?></strong>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                Customer Phone
                                                            </td>
                                                            <td> <strong><?php echo e($data->Getuser->phone); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                Address
                                                            </td>
                                                            <?php
                                                                $string_aaddress = json_decode($data->full_address, true);
                                                            ?>

                                                            <td> <strong> <?php echo e($string_aaddress['landmark']); ?>,<br>
                                                                    <?php echo e($string_aaddress['address_2']); ?>,<br>
                                                                    <?php echo e($string_aaddress['address_2']); ?>,<br>
                                                                    <?php echo e($string_aaddress['city']); ?>,<br>
                                                                    <?php echo e($string_aaddress['state']); ?>,<?php echo e($string_aaddress['pincode']); ?>,<br>
                                                                    <?php echo e($string_aaddress['alternate_number']); ?></strong>
                                                            </td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col">
                                                <table class="table table-bordered">

                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                Payment Method
                                                            </td>
                                                            <td> <strong>RazorPay</strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                Status
                                                            </td>
                                                            <td> <span
                                                                    class="badge bg-label-info me-1"><?php echo e($data->status); ?></span>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                Amount (inc: Delivery Charge)
                                                            </td>
                                                            <td> <strong>₹<?php echo e($data->amount); ?></strong></td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                Delivery Charges
                                                            </td>
                                                            <td> <strong>₹<?php echo e($data->delivery_charge); ?></strong></td>
                                                        </tr>


                                                        <tr>
                                                            <td>
                                                                Tracking Link
                                                            </td>
                                                            <td>
                                                                <?php if($data->traking_link == null): ?>
                                                                    <strong>Not Shipped Yet</strong>
                                                                <?php else: ?>
                                                                    <a href="<?php echo e($data->traking_link); ?>"><button
                                                                            type="button" class="btn btn-success"><i
                                                                                class="fas fa-shipping-fast"></i>&nbsp;Track</button></a>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                    </div>

                                    <hr class="mt-2" />

                                    <div class="card">
                                        <h5 class="card-header">Order Items </h5>
                                        <div class="table table-responsive">
                                            <table class="table  table-bordered">
                                                <thead class="table-primary">
                                                    <tr>

                                                        <th>Doc Name</th>

                                                        <th>Instructions</th>
                                                        <th>Total Pages</th>

                                                        <th>Print Config</th>
                                                        <th>Page Config</th>
                                                        <th>Binding Config</th>
                                                        <th>Total Copies</th>
                                                        <th>Download</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-border-bottom-0" id="part_body">
                                                    <?php $__currentLoopData = $data->Userdocs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr class="item particularrow">
                                                            <td><strong><?php echo e($items->doc_name); ?></strong></td>

                                                            <td><strong><?php echo e($items->instructions); ?></strong></td>
                                                            <td><strong><?php echo e($items->total_pages); ?></strong></td>
                                                            <td><strong><?php echo e(ucwords(str_replace('_', ' ', $items->print_config))); ?></strong>
                                                            </td>
                                                            <td><strong><?php echo e(ucwords(str_replace('_', ' ', $items->page_config))); ?></strong>
                                                            </td>
                                                            <td><strong><?php echo e(ucwords(str_replace('_', ' ', $items->binding_config))); ?></strong>
                                                            </td>
                                                            <td><strong><?php echo e($items->copies_count); ?></strong></td>
                                                            <td class="text-center"> <a
                                                                    href="<?php echo e(route('emp.order.download', ['id' => $items->id])); ?>"><button
                                                                        type="button" id="addmore"
                                                                        class="btn btn-icon btn-success">
                                                                        <i class="fa-solid fa-download"></i>
                                                                    </button></a></td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>

                                        </div>
                                    </div>
                                </form>
                                <div class="d-flex justify-content-end gap-2">

                                    <a href="<?php echo e(route('EmpDashboard')); ?>"> <button type="button"
                                            class="btn btn-secondary">Back</button></a>

                                    <?php if($data->status == 'placed'): ?>
                                        <button type="button" class="btn btn-success" id="accept"
                                            onclick="accept($(this).attr('orderid'))"
                                            orderid=<?php echo e($data->order_id); ?>>Accept</button>
                                    <?php elseif($data->status == 'processing'): ?>
                                        <button type="button" class="btn btn-success"
                                            onclick="shipped($(this).attr('orderid'))" id="shipped"
                                            orderid=<?php echo e($data->order_id); ?>>Click To Update
                                            Shipping Status</button>
                                    <?php elseif($data->status == 'shipped'): ?>
                                    <button type="button" class="btn btn-success"
                                    onclick="deliverd($(this).attr('orderid'))" id="delivered"
                                    orderid=<?php echo e($data->order_id); ?>>Click To Update Staus To Delivered</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <!-- /Account -->

                        </div>

                    </div>
                </div>
            <?php endif; ?>

            
            <script>
                function accept(orderid) {
                    swal({
                            title: "Are you sure?",
                            text: "You Want To Accept This Order!",
                            icon: "info",
                            buttons: true,
                            dangerMode: true,
                        })
                        .then((willDelete) => {

                            if (willDelete) {
                                $.post("<?php echo e(route('emp.order.accept')); ?>", {
                                        order_id: orderid,
                                        _token: '<?php echo e(csrf_token()); ?>'
                                    },
                                    function(data, status) {
                                        if (data.status == 'true') {
                                            swal("Good job!", data.message, "success").then((value) => {
                                                location.reload();
                                            });

                                        } else
                                            swal("Invalid", data.message, "error");
                                    },
                                    "json")
                            }

                        });
                }


                function shipped(orderid) {
                    swal("Kindly Provide Traking Link To Us", {
                            content: "input",
                        })
                        .then((value) => {
                            $.post("<?php echo e(route('emp.order.shipped')); ?>", {
                                    order_id: orderid,
                                    link: value,
                                    _token: '<?php echo e(csrf_token()); ?>'
                                },
                                function(data, status) {
                                    if (data.status == 'true') {
                                        swal("Good job!", data.message, "success").then((value) => {
                                            location.reload();
                                        });

                                    } else
                                        swal("Invalid", data.message, "error");
                                },
                                "json")
                        });
                }



                function deliverd(orderid) {
                    swal({
                            title: "Are you sure?",
                            text: "You Want To Set Deliverd Status For This Order!",
                            icon: "info",
                            buttons: true,
                            dangerMode: true,
                        })
                        .then((willDelete) => {

                            if (willDelete) {
                                $.post("<?php echo e(route('emp.order.deliverd')); ?>", {
                                        order_id: orderid,
                                        _token: '<?php echo e(csrf_token()); ?>'
                                    },
                                    function(data, status) {
                                        if (data.status == 'true') {
                                            swal("Good job!", data.message, "success").then((value) => {
                                                location.reload();
                                            });

                                        } else
                                            swal("Invalid", data.message, "error");
                                    },
                                    "json")
                            }

                        });
                }
            </script>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Empdash.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sudip\OneDrive\Documents\SastaPrint\resources\views/Empdash/orders.blade.php ENDPATH**/ ?>