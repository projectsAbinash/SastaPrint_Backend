
<?php $__env->startSection('title'); ?>
    <?php echo e('Area Control'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4">
                        <h5 class="card-header">Set And Control Area</h5>
                        <!-- Account -->

                        <hr class="my-0" />
                        <div class="card-body">
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?><br />
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <form id="formAccountSettings" method="POST" action="<?php echo e(route('admin.setaddress.post')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="Pin" class="form-label">Pin Code</label>
                                        <input class="form-control <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number"
                                            value="<?php echo e(old('pin')); ?>" id="pin" name="pin"
                                            placeholder="Enter area Pin Code" autofocus />
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <label for="State" class="form-label">State</label>
                                        <input class="form-control" type="text"
                                            id="state" name="state" disabled />
                                    </div>


                                </div>
                                <div class="mt-2">
                                    <button type="submit" class="btn btn-primary me-2" id="pnsbmt" disabled>Add</button>
                                    <a href="<?php echo e(url()->previous()); ?>"> <button type="button"
                                            class="btn btn-outline-secondary">Cancel</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /Account -->
                    </div>

                </div>
            </div>
            

            <div class="row">
                <div class="col">
                    <div class="card">
                        <h5 class="card-header">Active Area Pin Codes</h5>
                        <div class="table table">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Pin Code</th>
                                        <th>State</th>
                                    </tr>
                                </thead>
                                     <?php
                                     $added = $addedlist->where('status','added');
                                      $i = 0;  
                                    ?>
                                <tbody class="table-border-bottom-0">
                                    <?php $__currentLoopData = $added; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                      $i++  
                                    ?>
                                    <tr>
                                        <td><?php echo e($i); ?></td>
                                        <td><?php echo e($datas->pincode); ?></td>
                                        <td><?php echo e($datas->state); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card">
                        <h5 class="card-header">Top Requested Pin Code</h5>
                        <div class="table table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="text-center">#</th>
                                        <th class="text-center">Pin Code</th>
                                        <th class="text-center">State</th>
                                        <th class="text-center">Count</th>
                                    </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                    <?php
                                 $item = $requestlist->where('status','request')->get();
                                 $i = 0;  
                                    ?>
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                  $i++  
                                ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($i); ?></td>
                                        <td class="text-center"><?php echo e($data->pincode); ?></td>
                                        <td class="text-center"><?php echo e($data->state); ?></td>
                                        <td class="fw-bold text-center"><?php echo e($data->count); ?></td>
                                    </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
         

            <script>
                $(document).ready(function() {
                   
                    $('#pin').on('keyup', function() {
                        if ($(this).val().length == 6) {
                           
                            $.post("<?php echo e(route('api.fetchpin')); ?>", {
                                    pincode: $("#pin").val(),
                                },
                                function(data, status) {
                                    if (status === "success") {
                                        if (data.status == 'true') {
                                            console.log(data);
                                            $("#state").val(data.state);
                                            $("#pnsbmt").prop('disabled',false);
                                        }else{
                                            console.log(data);
                                            $("#pnsbmt").prop('disabled',true);
                                            $("#state").val("");
                                            alert("Invalid Pin Code");
                                        }
                                    }
                                },
                                "json")

                        }else{
                            $("#pnsbmt").prop('disabled',true);
                        }
                    });

                });
            </script>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admins.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sudip\OneDrive\Documents\SastaPrint\resources\views/Admins/setting.blade.php ENDPATH**/ ?>