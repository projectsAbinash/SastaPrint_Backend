
<?php $__env->startSection('title'); ?>
    <?php echo e('Orders'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <?php if($view == 'list'): ?>
                <div class="card">
                    <h5 class="card-header">Orders List</h5>
                    <div class="table-responsive text-nowrap">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-center">Type</th>
                                    <th class="text-center">Customer name</th>
                                    <th class="text-center">Order Id</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center">
                                            1
                                        </td>
                                        <td class="text-center">
                                            <img style="max-height: 45px;"
                                                src="<?php echo e(url('AdminAssets/Source/assets/img/pdf.jpg')); ?>" alt="Avatar" />
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('CustomeDetails', ['id' => $item->Getuser->id])); ?>"><?php echo e($item->Getuser->name); ?></a>
                                        </td>
                                        <td class="text-center fw-bold">
                                            #<?php echo e($item->order_id); ?>

                                        </td>
                                        <td class="text-center fw-bold">
                                            ₹<?php echo e($item->amount); ?>


                                        </td>
                                       
                                        <td class="text-center">
                                            <?php if($item->status == 'placed'): ?>
                                            <span class="badge bg-label-info me-1">Placed</span>
                                            <?php elseif($item->status == 'shipped'): ?>
                                            <span class="badge bg-label-warning me-1">Shippted</span>
                                            <?php elseif($item->status == 'deliverd'): ?>
                                            <span class="badge bg-label-success me-1">Delivred</span>

                                            <?php else: ?>
                                            <span class="badge bg-label-danger me-1"><?php echo e($item->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('orders.details', ['id' => 1])); ?>"> <i
                                                    class="fa-regular fa-eye text-primary" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="View And Manage Order"
                                                    style="font-size:20px;"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
        </div>
    <?php elseif($view == 'details'): ?>
        <?php endif; ?>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admins.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sudip\OneDrive\Documents\SastaPrint\resources\views/Admins/Orders.blade.php ENDPATH**/ ?>