
<?php $__env->startSection('title'); ?>
    <?php echo e('Notifications'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-md-12">
                    <div class="card mb-4">
                        <h5 class="card-header">Send Notificatons</h5>
                        <!-- Account -->

                        <hr class="my-0" />
                        <div class="card-body">
                            <?php if(session('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($error); ?><br />
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                            <form id="formAccountSettings" method="POST" action="<?php echo e(route('notification.post')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3 col-md-6">
                                        <label for="Title" class="form-label">Title</label>
                                        <input class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                            value="<?php echo e(old('title')); ?>" id="Title" name="title"
                                            placeholder="This Is A Title" autofocus />
                                    </div>

                                    <div class="mb-3 col-md-6">
                                        <label for="Meassage" class="form-label">Meassage</label>
                                        <input class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text"
                                            id="Meassage" name="message" value="<?php echo e(old('message')); ?>"
                                            placeholder="Todays Best Offers" />
                                    </div>


                                </div>
                                <div class="mt-2">
                                    <button type="submit" class="btn btn-primary me-2">Send</button>
                                    <a href="<?php echo e(url()->previous()); ?>"> <button type="button"
                                            class="btn btn-outline-secondary">Cancel</button></a>
                                </div>
                            </form>
                        </div>
                        <!-- /Account -->
                    </div>

                </div>
            </div>
            <div class="card">
                <h5 class="card-header">Last Notifications Lists</h5>
                <div class="table table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th class="text-center">Title</th>
                                <th class="text-center">Message</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Provider</th>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php $__currentLoopData = $getlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($data->id); ?></td>
                                    <td class="text-center fw-bold"><?php echo e($data->title); ?></td>
                                    <td class="text-center" style="max-width: 13rem;">
                                        <?php echo e($data->message); ?>


                                    </td>
                                    <td class="text-center">
                                        <?php if($data->status == 'true'): ?>
                                            <span class="badge bg-label-success me-1">Pushed</span>
                                        <?php else: ?>
                                            <span class="badge bg-label-danger me-1">Not Pushed</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-center">
                                        <img style="max-height: 45px;"
                                            src="<?php echo e(url('AdminAssets/Source/assets/img/OneSignal_Logo-removebg-preview.png')); ?>"
                                            alt="Avatar" class="rounded-circle" />
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
                <div class="p-3">
                    <?php echo e($getlist->links('pagination::bootstrap-5')); ?>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admins.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sudip\OneDrive\Documents\SastaPrint\resources\views/Admins/notification.blade.php ENDPATH**/ ?>