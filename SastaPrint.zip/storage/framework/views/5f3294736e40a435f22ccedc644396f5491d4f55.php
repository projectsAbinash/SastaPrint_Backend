
<?php $__env->startSection('title'); ?>
    <?php echo e('Manage Papers'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
            <div class="card">
                <h5 class="card-header">Papers Management</h5>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>Name</th>
                                    <th>Order ID</th>

                                    <th>Paper Quantity</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th colspan="2" class="text-center">Action</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $getrow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>1</td>
                                        <td><a href="#">
                                            </a><?php echo e($item->Getemp->name); ?></td>
                                        <td><?php echo e($item->order_id); ?></td>
                                        <td><strong><?php echo e($item->quantity); ?></strong></td>
                                        <td><?php echo e($item->created_at->format('d-m-Y')); ?></td>
                                        <td>
                                            <?php if($item->status == 'pending'): ?>
                                                <span class="badge bg-label-info me-1">Pending</span>
                                            <?php elseif($item->status == 'approved'): ?>
                                                <span class="badge bg-label-success me-1">Approved</span>
                                            <?php elseif($item->status == 'rejected'): ?>
                                                <span class="badge bg-label-danger me-1">Rejected</span>
                                            <?php else: ?>
                                                <span class="badge bg-label-danger me-1"><?php echo e($item->status); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-danger text-center fs-5">
                                            <a href="<?php echo e(route('Admin.employee.rejectpaper',(['id' => $item->id]))); ?>" onclick="return confirm('Are you sure you want to Reject this Request')"><i class="uil uil-ban text-danger"></i></a>
                                        </td>
                                        <td class="text-success text-center fs-5">
                                            <i class="uil uil-check-circle" id="accept"
                                                onclick="check($(this).attr('orderid'))" orderid=<?php echo e($item->order_id); ?>></i>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function check(orderid) {
            console.log(orderid);
            swal("Enter MPIN To Accept This Request:", {
                    content: "input",
                })
                .then((value) => {

                    $.post("<?php echo e(route('Admin.employee.Papersapprove')); ?>", {
                            order_id: orderid,
                            mpin: value,
                            _token: '<?php echo e(csrf_token()); ?>'
                        },
                        function(data, status) {
                            if (data.status == 'true') {
                                swal("Good job!", data.message, "success").then((value) => {
                                    location.reload();
                                });

                            } else
                                swal("Invalid", data.message, "error");
                        },
                        "json")

                });
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admins.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sudip\OneDrive\Documents\SastaPrint\resources\views/Admins/papers.blade.php ENDPATH**/ ?>