
<?php $__env->startSection('title'); ?>
    <?php echo e('Dashboard'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">



        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Admins.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sudip\OneDrive\Documents\SastaPrint\resources\views/Admins/Dashboard.blade.php ENDPATH**/ ?>