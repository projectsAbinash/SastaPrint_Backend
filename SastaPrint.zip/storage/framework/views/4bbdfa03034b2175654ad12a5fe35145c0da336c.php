
<?php $__env->startSection('title'); ?>
    <?php echo e('Manage Papers'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-container'); ?>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">


            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="card" style="background-color: #696cff33;">

                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 style="color:#696cff;">Available Papers</h5>
                            <h4 class="fw-bold" style="color:#696cff;"><img
                                    src="<?php echo e(url('AdminAssets/Source/assets/img/icons/unicons/wallet.svg')); ?>"
                                    alt="chart success" style="height: 30px;" class="rounded" />
                                <?php echo e($data->available_papers); ?></h4>
                        </div>
                        <div class="col">
                            <div class="d-flex justify-content-end">
                                <button type="button" data-bs-toggle="modal" data-bs-target="#basicModal"
                                    class="btn btn-primary mt-4"><i class="uil uil-plus"></i> Request For
                                    Papers</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="card">
                <h5 class="card-header">Papers Request History</h5>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>id</th>
                                    <th>Order ID</th>
                                    <th>Paper Quantity</th>
                                    <th>Date</th>
                                    <th>Status</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $id = 0;
                                ?>
                                <?php $__currentLoopData = $data->PaperRequ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $id++;
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo e($id); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->order_id); ?>

                                        </td>
                                        <td class="fw-bold">
                                            <?php echo e($item->quantity); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->created_at->format('d-m-Y')); ?>

                                        </td>
                                        <td>
                                            <?php if($item->status == 'pending'): ?>
                                                <span class="badge bg-label-info me-1">Pending</span>
                                            <?php elseif($item->status == 'approved'): ?>
                                                <span class="badge bg-label-success me-1">Approved</span>
                                            <?php elseif($item->status == 'rejected'): ?>
                                                <span class="badge bg-label-danger me-1">Rejected</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>





            <!-- Modal -->
            <div class="modal fade" id="basicModal" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel1">Request For Papers</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col mb-3">
                                    <form action="<?php echo e(route('mngpaper.request')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <label for="nameBasic" class="form-label">Quantity</label>

                                        <h5 class="card-header">Basic Radio</h5>
                                        
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                            <button type="submit" class="btn btn-primary">Request</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Empdash.Layouts.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sudip\OneDrive\Documents\SastaPrint\resources\views/Empdash/mngpaper.blade.php ENDPATH**/ ?>